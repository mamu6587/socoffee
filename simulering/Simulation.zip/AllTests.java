import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({LaneTest.class, TrafficSystemTest.class })
public class AllTests {

}
//Car �r meningsl�s att testa; l�gga in ett "Knows their placetest" f�r trafficsys?